[![built-with-azurra-framework](https://github.com/Elbullazul/Azurra_framework/raw/assets/azurra_framework_smaller.png)](https://github.com/Elbullazul/Azurra_framework)

# macOS 11 'Big Sur'

Theme reproducing the clean and bright look of Apple's OS [(dark theme here)](https://github.com/B00merang-Project/macOS-Dark)

![macOS](https://cdn.pling.com/img/5/f/7/b/fdcf0e050fadab9fdf68cce537d40668f0de.png)

**Maintainer :** [Elbullazul](https://github.com/Elbullazul)

**Distributor :** [B00merang Project](https://github.com/B00merang-Project)

**License :** GPL v3

**More info :** http://b00merang.weebly.com/macos.html

### Manual installation

Extract the zip file to the themes directory i.e. `/home/USERNAME/.themes`

### Requirements

- GTK+ 3.16 or above
- Murrine and Pixmap theme engines

### Contribute

Contact us @ http://b00merang.weebly.com/contact.html
